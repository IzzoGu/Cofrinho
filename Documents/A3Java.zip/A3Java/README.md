# Projeto Cofrinho

## Descrição
Este é um projeto de sistema de cofrinho desenvolvido em Java. O sistema permite gerenciar e controlar um cofrinho digital.

## Tecnologias Utilizadas
- Java
- H2 Database (para armazenamento de dados)
- Maven (para gerenciamento de dependências)

## Estrutura do Projeto
```
.
├── cofrinho/          # Diretório principal do projeto
├── data/             # Diretório para dados
└── .vscode/          # Configurações do VS Code
```

## Como Executar
1. Certifique-se de ter o Java instalado em sua máquina
2. Clone este repositório
3. Execute o projeto usando Maven:
   ```bash
   mvn clean install
   mvn exec:java
   ```

## Funcionalidades
- Gerenciamento de cofrinho
- Armazenamento de dados em banco H2
- Interface de usuário via console

## Contribuição
Para contribuir com o projeto:
1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## Licença
Este projeto está sob a licença MIT. 