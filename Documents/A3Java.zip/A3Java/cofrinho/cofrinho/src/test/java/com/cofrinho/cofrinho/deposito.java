package com.cofrinho.cofrinho;

public class deposito {
    private double valor;

    public deposito(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }
}